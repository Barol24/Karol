require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const Food = require('./models/Food');

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

  setTimeout(() => {
  mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));
}, 5000); // espera 5 segundos

app.get('/foods', async (req, res) => {
  const foods = await Food.find();
  res.json(foods);
});

app.post('/foods', async (req, res) => {
  const newFood = new Food(req.body);
  await newFood.save();
  res.status(201).json(newFood);
});

app.delete('/foods/:id', async (req, res) => {
  await Food.findByIdAndDelete(req.params.id);
  res.status(204).send();
});

app.listen(3000, () => console.log('API running on port 3000'));